Problems I had:

    The first main issue I had was dynamically allocating memory for the 2D
array. It wasn't that I didn't know how to look it up, but I was trying to 
work through the logic to ensure I understand the concept. Turns out, I couldn't
and didn't catch that until after you looked over my code. Needless to say, 
I doubt that's a concept I'll ever forget. 

    Next and probably the most frustrating was figuring out where the bug was in 
my code. I feel like I went through an entire expo marker tracing through my 
algorithms, ensuring there wasn't a flaw in my logic. I spent about 5 hours
building the program and about another 10-12 debugging that silly error. 
Turned out to be an error in my parameters sending to writePixel function. 

    One of the best learning objectives I took away was your advice to write 
everything out on paper. Cathy talked about doing this last semester, but that 
was only at the beginning. At that time, I did not have a firm grasp of C, 
much less the software development cycle. Now that I know what I'm doing (or so 
I believe), writing my algorithms down on paper and on my whiteboard saved so 
much time. I understood what I needed to do and could physically see it before
even typing a line of code. 



Thoughts on the Assignment:

    I thoroughly enjoyed it. I think this is a cool concept that is used a lot 
in the modern world. I think what would have set this Programming Assignment
to the next level would be a brief introduction and discuss some of the modern
applications. In my research, it's widely used in cybersecurity, mainly for 
bad guys to communicate. Just doing a quick 10-minute google search got me 
really excited about the topic. 